module.exports = {
  PackageDumData: [
    {
      "packageName": "Package 1",
      "packageId": "app.witwork.vpn.ios.gold_monthly",
      "packagePricing": 0,
      "packagePlatform": "ios",
      "packageDuration": "monthly"
    },
    {
      "packageName": "Package 2",
      "packageId": "app.witwork.vpn.ios.gold_yearly",
      "packagePricing": 0,
      "packagePlatform": "ios",
      "packageDuration": "yearly"
    },
    {
      "packageName": "Package 3",
      "packageId": "ape.vpn.android.weekly",
      "packagePricing": 0,
      "packagePlatform": "android",
      "packageDuration": "weekly"
    },
    {
      "packageName": "Package 4",
      "packageId": "ape.vpn.android.monthly",
      "packagePricing": 0,
      "packagePlatform": "android",
      "packageDuration": "monthly"
    }
  ]
}